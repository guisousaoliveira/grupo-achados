# Estúdio Aster

Linha de montagem dos vídeos longos (estilo Velum). Um projeto = uma pasta em `projetos/<nome>/`.

## Fluxo de um vídeo

| Etapa | Quem | Comando / arquivo |
|---|---|---|
| 1. Tema | Claude sugere, Guilherme escolhe | — |
| 2. Roteiro em 6 blocos | Claude escreve, Guilherme aprova | `projetos/<nome>/roteiro.md` (cada bloco começa com `## `) |
| 3. Voz | Guilherme gera 1 áudio por bloco no ElevenLabs | `projetos/<nome>/voz/bloco1.mp3 ... bloco6.mp3` |
| 4. Alinhar voz e roteiro | automático | `python alinhar.py projetos/<nome>` → `voz.wav` + `tl_voz.json` |
| 5. Imagens | automático (Wikimedia / Library of Congress) | `buscas.txt` + `bash baixar_lista.sh projetos/<nome>` ou `python buscar_midia.py ...` |
| 6. Plano de cenas | Claude escreve | `projetos/<nome>/planos.json` |
| 7. Amostra de 1 min | automático | `python montar.py projetos/<nome> --amostra 60` |
| 8. Vídeo completo + DaVinci | automático | `python montar.py projetos/<nome>` |

Saída em `projetos/<nome>/saida/`: o mp4, `davinci_horizontal/` (clipes limpos, textos em PNG, voz/música/efeitos separados e `timeline_davinci.fcpxml`), e `conferencia.jpg/.txt` (um quadro de cada plano + avisos: plano curto demais, etiqueta que some rápido, zoom além da resolução, áudio estourando).

## Peças visuais (motor.py)

- `full`: obra em tela cheia com zoom/pan lento (`de` e `ate` = centro x, centro y, largura, em fração da imagem)
- `framed`: imagem menor sobre o fundo petróleo (retratos, outras obras); `nome` aparece ao lado
- `year`: ano gigante em serifada, com a obra atrás
- `quote`: citação em itálico sobre a obra escurecida
- `music`: título da música + compositor e linha de onda que segue a trilha
- `fim`: tela do ASTER
- Em qualquer plano: `etiqueta: ["Título", "Autor (ano)"]` no canto inferior esquerdo

Fontes: Cormorant Garamond e Playfair Display (licença OFL, em `fontes/`). Marca em `marca/`.

## Requisitos

Python 3.10+, `pip install numpy pillow` e o FFmpeg instalado. Renderizar 1 min leva ~10 min num PC de 4 núcleos.
