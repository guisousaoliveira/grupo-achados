# Motor de render do Aster (estilo Velum). Um plano = uma imagem + um movimento + textos.
# Modos de plano:
#   full    obra em tela cheia, pan/zoom lento de "de" até "ate" (caixas (cx, cy, largura) em fração da imagem)
#   framed  imagem menor sobre o fundo escuro (retratos, outras obras), zoom leve dentro da moldura
#   year    ano gigante em serifada, com ou sem imagem atrás
#   quote   citação em itálico sobre a obra escurecida (ou sobre o fundo)
#   music   cartão da música: título + compositor e uma linha de onda sonora
#   fim     tela final do Aster
# Textos opcionais em qualquer plano: etiqueta=[título, autor (ano)] no canto inferior esquerdo,
#   nome="Pessoa" ao lado do retrato (framed).
import math, os, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

FPS = 24
AQUI = os.path.dirname(os.path.abspath(__file__))
FT = os.path.join(AQUI, 'fontes') + os.sep
MARCA = os.path.join(AQUI, 'marca') + os.sep
BG = (10, 20, 23)          # azul-petróleo quase preto da marca
PAPEL = (233, 224, 204)    # marfim do logo
MUTED = (178, 170, 154)
VERMELHO = (178, 52, 44)   # estrela do olho

_fontes = {}


def F(nome, tam, var=None):
    k = (nome, tam, var)
    if k not in _fontes:
        f = ImageFont.truetype(FT + nome, tam)
        if var:
            f.set_variation_by_name(var)
        _fontes[k] = f
    return _fontes[k]


def ease(x):
    return 0.5 - 0.5 * math.cos(math.pi * min(1, max(0, x)))


_cache = {}


def carregar(path, maxlado=4200):
    if path not in _cache:
        im = Image.open(path); im.load(); im = im.convert('RGB')
        s = maxlado / max(im.size)
        if s < 1:
            im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
        _cache[path] = im
    return _cache[path]


def fundo(W, H):
    # fundo da marca: petróleo com centro um pouco mais claro
    k = ('bg', W, H)
    if k not in _cache:
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        r = np.sqrt(((xx - W / 2) / (W * 0.6)) ** 2 + ((yy - H / 2) / (H * 0.6)) ** 2)
        luz = np.clip(1.25 - 0.45 * r, 0.7, 1.25)[..., None]
        _cache[k] = Image.fromarray(np.clip(np.array(BG, np.float32) * luz, 0, 255).astype(np.uint8))
    return _cache[k].copy()


def caixa(c, iw, ih, asp):
    # (cx, cy, largura) em fração da imagem -> caixa em pixels com o aspecto do quadro, dentro da imagem
    cx, cy, w = c[0] * iw, c[1] * ih, c[2] * iw
    h = w / asp
    if h > ih:
        h = ih; w = h * asp
    if w > iw:
        w = iw; h = w / asp
    cx = min(max(cx, w / 2), iw - w / 2); cy = min(max(cy, h / 2), ih - h / 2)
    return cx, cy, w


def quadro_full(s, W, H, lt):
    im = carregar(s['img']); iw, ih = im.size; asp = W / H
    a = caixa(s['de'], iw, ih, asp); b = caixa(s.get('ate', s['de']), iw, ih, asp)
    e = ease(lt)
    w = a[2] * math.exp(math.log(b[2] / a[2]) * e)          # zoom com velocidade constante
    cx = a[0] + (b[0] - a[0]) * e; cy = a[1] + (b[1] - a[1]) * e
    h = w / asp
    cx = min(max(cx, w / 2), iw - w / 2); cy = min(max(cy, h / 2), ih - h / 2)
    return im.resize((W, H), Image.BICUBIC, box=(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2))


def quadro_framed(s, W, H, lt):
    im = carregar(s['img']); iw, ih = im.size
    x0, y0, x1, y1 = s.get('recorte', [0, 0, 1, 1])
    bx = [x0 * iw, y0 * ih, x1 * iw, y1 * ih]; bw, bh = bx[2] - bx[0], bx[3] - bx[1]
    tam = s.get('tamanho', 0.72)                             # fração da altura da tela
    sc = min(W * 0.62 / bw, H * tam / bh)
    z = 1 + s.get('zoom', 0.05) * ease(lt)
    cw, ch = bw / z, bh / z; cx = (bx[0] + bx[2]) / 2; cy = (bx[1] + bx[3]) / 2
    pw, ph = round(bw * sc), round(bh * sc)
    pic = im.resize((pw, ph), Image.LANCZOS, box=(cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2))
    out = fundo(W, H)
    px = {'centro': (W - pw) / 2, 'direita': W * 0.62 - pw / 2, 'esquerda': W * 0.38 - pw / 2}[s.get('posicao', 'centro')]
    out.paste(pic, (round(px), round(H * 0.46 - ph / 2)))
    s['_caixa'] = (px, H * 0.46 - ph / 2, px + pw, H * 0.46 + ph / 2)
    return out


def quadro_year(s, W, H, lt):
    out = fundo(W, H) if not s.get('img') else escurecer(quadro_framed(dict(s, tamanho=0.78), W, H, lt), 1.0)
    L = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    f = F('PF.ttf', round(H * 0.42), 'Bold')
    a = min(1, lt / 0.15) * min(1, (1 - lt) / 0.12)
    sobe = (1 - ease(min(1, lt / 0.4))) * H * 0.02
    d.text((W / 2, H / 2 + sobe), s['texto'], font=f, fill=PAPEL + (round(255 * max(0, a)),), anchor='mm')
    return Image.alpha_composite(out.convert('RGBA'), L).convert('RGB')


def escurecer(im, k):
    return Image.blend(Image.new('RGB', im.size, BG), im, k)


def quadro_quote(s, W, H, lt):
    base = quadro_full(s, W, H, lt) if s.get('img') else fundo(W, H)
    return escurecer(base, 0.38) if s.get('img') else base


def quadro_music(s, W, H, lt):
    out = fundo(W, H); d = ImageDraw.Draw(out)
    a = min(1, lt / 0.12)
    cor = lambda c: tuple(round(BG[i] + (c[i] - BG[i]) * a) for i in range(3))
    d.text((W / 2, H * 0.30), s['titulo'], font=F('CG.ttf', round(H * 0.045), 'Medium'), fill=cor(PAPEL), anchor='mm')
    d.text((W / 2, H * 0.355), s['compositor'], font=F('CGi.ttf', round(H * 0.033), 'Italic'), fill=cor(MUTED), anchor='mm')
    # linha de onda: amplitude segue o volume da música naquele instante
    env = s.get('_env') or [0.3]                       # volume da trilha, 10 amostras por segundo
    amp = env[min(len(env) - 1, int((s['_t0'] + lt * s['_dur']) * 10))]
    pts = []
    for x in range(0, W + 1, 6):
        u = x / W
        y = H * 0.62 + math.sin(u * 22 + lt * 9) * math.exp(-((u - 0.5) * 3.2) ** 2) * H * 0.06 * amp
        pts.append((x, y))
    d.line(pts, fill=cor(PAPEL), width=3)
    return out


def quadro_fim(s, W, H, lt):
    k = ('fim', W, H)
    if k not in _cache:
        _cache[k] = Image.open(MARCA + 'aster-tela-16x9.png').convert('RGB').resize((W, H), Image.LANCZOS)
    a = min(1, lt / 0.25)
    return escurecer(_cache[k], a)


def quadro_black(s, W, H, lt):
    return fundo(W, H)


QUADROS = dict(full=quadro_full, framed=quadro_framed, year=quadro_year, quote=quadro_quote,
               music=quadro_music, fim=quadro_fim, black=quadro_black)


def quebrar(d, texto, f, maxw):
    out, linha = [], ''
    for w in texto.split():
        t = (linha + ' ' + w).strip()
        if d.textlength(t, font=f) <= maxw:
            linha = t
        else:
            out.append(linha); linha = w
    if linha:
        out.append(linha)
    return out


def sombra(L, desenhar, raio, forca):
    T = Image.new('RGBA', L.size, (0, 0, 0, 0)); desenhar(ImageDraw.Draw(T), (0, 0, 0, 255))
    a = np.asarray(T.filter(ImageFilter.GaussianBlur(raio))).copy()
    a[..., 3] = np.clip(a[..., 3].astype(np.int32) * forca, 0, 220).astype(np.uint8)
    L.alpha_composite(Image.fromarray(a))
    desenhar(ImageDraw.Draw(L), None)


def camada_texto(s, W, H):
    # tudo o que é texto fica numa camada separada (vira PNG no pacote do DaVinci)
    L = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    if s.get('etiqueta'):
        t1, t2 = s['etiqueta']
        f1 = F('CGi.ttf', round(H * 0.034), 'SemiBold Italic'); f2 = F('CG.ttf', round(H * 0.023), 'Medium')
        x, y = W * 0.03 + H * 0.022, H * 0.87
        # placa escura translúcida com filete vermelho: lê em cima de qualquer imagem
        larg = max(d.textlength(t1, font=f1), d.textlength(t2 or '', font=f2))
        alt = f1.size * 1.15 + (f2.size * 1.25 if t2 else 0)
        px, py = H * 0.022, H * 0.016
        P = Image.new('RGBA', (W, H), (0, 0, 0, 0)); dp = ImageDraw.Draw(P)
        dp.rounded_rectangle((x - px, y - py, x + larg + px, y + alt + py), radius=round(H * 0.006), fill=(8, 14, 16, 175))
        dp.rectangle((x - px, y - py, x - px + max(3, round(H * 0.004)), y + alt + py), fill=VERMELHO + (255,))
        L.alpha_composite(P.filter(ImageFilter.GaussianBlur(0.6)))
        def des(dd, cor):
            dd.text((x, y), t1, font=f1, fill=cor or PAPEL + (255,))
            if t2:
                dd.text((x, y + f1.size * 1.15), t2, font=f2, fill=cor or MUTED + (255,))
        sombra(L, des, 4, 2)
    if s.get('nome') and s.get('_caixa'):
        x0, y0, x1, y1 = s['_caixa']; f = F('CGi.ttf', round(H * 0.036), 'Medium Italic')
        if s.get('posicao') == 'esquerda':
            d.text((x1 + W * 0.03, (y0 + y1) / 2), s['nome'], font=f, fill=PAPEL + (255,), anchor='lm')
        else:
            d.text((x0 - W * 0.03, (y0 + y1) / 2), s['nome'], font=f, fill=PAPEL + (255,), anchor='rm')
    if s.get('citacao'):
        f = F('CGi.ttf', round(H * 0.048), 'Medium Italic')
        linhas = quebrar(d, s['citacao'], f, W * 0.62); lh = f.size * 1.25
        y = H / 2 - len(linhas) * lh / 2
        for ln in linhas:
            d.text((W / 2, y), ln, font=f, fill=PAPEL + (250,), anchor='ma'); y += lh
        if s.get('autor_citacao'):
            d.text((W / 2, y + H * 0.02), s['autor_citacao'], font=F('CG.ttf', round(H * 0.024), 'Medium'), fill=MUTED + (255,), anchor='ma')
    return L


_vig = {}


def efeito(fr, tg, W, H):
    # projetor quase invisível (Velum): weave < 1 px, flicker ~1,5%, grão fino, vinheta leve
    if (W, H) not in _vig:
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        r = np.sqrt(((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2)
        _vig[(W, H)] = (1 - 0.18 * np.clip(r - 0.6, 0, 1) ** 1.6)[..., None]
    dx = 0.7 * math.sin(2 * math.pi * tg * 0.73) + 0.3 * math.sin(2 * math.pi * tg * 1.91 + 1)
    dy = 0.6 * math.sin(2 * math.pi * tg * 0.57 + 2)
    sc = 1.004
    fr = fr.transform((W, H), Image.AFFINE, (1 / sc, 0, (W - W / sc) / 2 - dx, 0, 1 / sc, (H - H / sc) / 2 - dy), Image.BILINEAR)
    a = np.asarray(fr).astype(np.float32)
    rng = np.random.default_rng(int(tg * FPS + 0.5))
    k = 1 + 0.008 * math.sin(2 * math.pi * tg * 7.1) + 0.006 * (rng.random() - 0.5)
    g = rng.normal(0, 2.0, (H // 2, W // 2, 1)).astype(np.float32).repeat(2, 0).repeat(2, 1)
    return Image.fromarray(np.clip(a * k * _vig[(W, H)] + g, 0, 255).astype(np.uint8))


def render_plano(args):
    i, s, W, H, outdir, n, t0 = args
    limpo = f'{outdir}/clipes/plano_{i + 1:03d}.mp4'; final = f'{outdir}/_final/plano_{i + 1:03d}.mp4'
    enc = lambda p, crf: subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}',
                                           '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', str(crf),
                                           '-pix_fmt', 'yuv420p', '-g', '48', p], stdin=subprocess.PIPE)
    p1, p2 = enc(limpo, 17), enc(final, 16)
    s['_t0'], s['_dur'] = t0, n / FPS
    QUADROS[s['mode']](s, W, H, 0)                     # calcula a posição da moldura antes do texto
    L = camada_texto(s, W, H); tem = L.getbbox() is not None
    if tem:
        L.save(f'{outdir}/textos/texto_{i + 1:03d}.png')
    fin, fout = s.get('fade_in', 0), s.get('fade_out', 0)
    tin = s.get('texto_in', 0.4)
    for f in range(n):
        lt = (f + 0.5) / n; t = f / FPS
        fr = QUADROS[s['mode']](s, W, H, lt)
        k = 1.0
        if fin and t < fin:
            k = t / fin
        if fout and (n - f) / FPS < fout:
            k = min(k, (n - f) / FPS / fout)
        if k < 1:
            fr = escurecer(fr, k)
        fr = efeito(fr, t0 + t, W, H)
        p1.stdin.write(fr.tobytes())
        if tem:
            a = min(1, max(0, (t - tin) / 0.5), max(0, (n - f) / FPS - 0.1) / 0.4)
            l2 = L if a >= 1 else Image.fromarray((np.asarray(L).astype(np.float32) * np.array([1, 1, 1, a])).astype(np.uint8))
            fr = Image.alpha_composite(fr.convert('RGBA'), l2).convert('RGB')
        p2.stdin.write(fr.tobytes())
    for p in (p1, p2):
        p.stdin.close(); p.wait()
    return i
