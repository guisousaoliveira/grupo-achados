# Busca e baixa imagens de domínio público / licença livre (Wikimedia Commons ou Library of Congress).
# Uso: python buscar_midia.py PROJETO "consulta" [quantidade] [apelido] [fonte]
#   fonte: wiki (Wikimedia Commons, padrão) ou loc (Library of Congress: mapas, gravuras, fotos)
#   ex: python buscar_midia.py projetos/cantino "Cantino planisphere" 4 cantino
#       python buscar_midia.py projetos/cantino "portolan chart" 3 portulano loc
# Salva em PROJETO/media/img/ e anota autor, licença e link em PROJETO/media/creditos.json.
import json, os, re, sys, time, urllib.error, urllib.parse, urllib.request

API = 'https://commons.wikimedia.org/w/api.php'
UA = {'User-Agent': 'AsterEstudio/1.0 (https://github.com/guisousaoliveira/grupo-achados) python-urllib'}
LADO = 3840  # largura baixada; o Wikimedia só libera miniaturas em tamanhos padrão (3840, 1920...)


def get(url):
    # o Wikimedia limita pedidos por IP; espera e tenta de novo (respeita Retry-After)
    for tentativa in range(6):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=90) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code != 429 or tentativa == 5:
                raise
            espera = int(e.headers.get('Retry-After') or 0) or 5 * 2 ** tentativa
            if espera > 120:
                sys.exit('O Wikimedia bloqueou este computador por alguns minutos. Tente de novo mais tarde ou use a fonte loc.')
            print(f'  Wikimedia pediu pausa, aguardando {espera}s...', flush=True)
            time.sleep(espera)


def limpa(html):
    return re.sub(r'<[^>]+>', '', html or '').strip()


def thumb(titulo, largura):
    q = dict(action='query', format='json', titles=titulo, prop='imageinfo', iiprop='url', iiurlwidth=largura)
    pg = next(iter(json.loads(get(API + '?' + urllib.parse.urlencode(q)))['query']['pages'].values()))
    return (pg.get('imageinfo') or [{}])[0].get('thumburl')


def buscar(consulta, n):
    q = dict(action='query', format='json', generator='search', gsrsearch=f'filetype:bitmap {consulta}',
             gsrnamespace=6, gsrlimit=max(n * 3, 10), prop='imageinfo',
             iiprop='url|size|extmetadata|mime', iiurlwidth=LADO)
    d = json.loads(get(API + '?' + urllib.parse.urlencode(q)))
    paginas = sorted(d.get('query', {}).get('pages', {}).values(), key=lambda p: p.get('index', 0))
    out = []
    for p in paginas:
        ii = (p.get('imageinfo') or [{}])[0]
        if ii.get('mime') not in ('image/jpeg', 'image/png', 'image/tiff'):
            continue
        if ii.get('width', 0) < 1920:  # só alta resolução
            continue
        url = ii.get('thumburl') or ii['url']
        if url == ii['url']:  # original menor que 3840: pede a miniatura padrão de 1920
            url = thumb(p['title'], 1920) or url
        md = ii.get('extmetadata', {})
        out.append(dict(
            titulo=p['title'].removeprefix('File:'),
            url=url, pagina=ii.get('descriptionurl'),
            largura=ii['width'], altura=ii['height'],
            autor=limpa(md.get('Artist', {}).get('value')),
            data=limpa(md.get('DateTimeOriginal', {}).get('value')),
            licenca=limpa(md.get('LicenseShortName', {}).get('value')),
        ))
        if len(out) >= n:
            break
    return out


def buscar_loc(consulta, n):
    q = dict(q=consulta, fo='json', c=n * 3, fa='online-format:image')
    d = json.loads(get('https://www.loc.gov/search/?' + urllib.parse.urlencode(q)))
    out = []
    for r in d.get('results', []):
        urls = r.get('image_url') or []
        if not urls:
            continue
        m = re.match(r'(https://tile\.loc\.gov/image-services/iiif/[^/]+)/', urls[-1])
        dims = re.search(r'#h=(\d+)&w=(\d+)', urls[-1])
        if not m or not dims or int(dims.group(2)) < 1920:
            continue
        out.append(dict(titulo=r.get('title', ''), url=m.group(1) + f'/full/!{LADO},{LADO}/0/default.jpg',
                        pagina=r.get('id'), largura=int(dims.group(2)), altura=int(dims.group(1)),
                        autor=', '.join(r.get('contributor') or []), data=r.get('date', ''),
                        licenca='Library of Congress (verificar direitos na página)'))
        if len(out) >= n:
            break
    return out


def main():
    proj, consulta = sys.argv[1], sys.argv[2]
    n = int(sys.argv[3]) if len(sys.argv) > 3 else 4
    apelido = sys.argv[4] if len(sys.argv) > 4 else re.sub(r'\W+', '_', consulta.lower()).strip('_')[:30]
    pasta = os.path.join(proj, 'media', 'img'); os.makedirs(pasta, exist_ok=True)
    cred_f = os.path.join(proj, 'media', 'creditos.json')
    cred = json.load(open(cred_f, encoding='utf-8')) if os.path.exists(cred_f) else {}
    fonte = sys.argv[5] if len(sys.argv) > 5 else 'wiki'
    achados = buscar_loc(consulta, n) if fonte == 'loc' else buscar(consulta, n)
    if not achados:
        print('nada encontrado em alta resolução para:', consulta); return
    for i, a in enumerate(achados, 1):
        ext = '.png' if a['url'].lower().endswith('.png') else '.jpg'
        nome = f'{apelido}_{i}{ext}' if len(achados) > 1 else apelido + ext
        try:
            dados = get(a['url'])
        except Exception as e:
            print('falhou', a['titulo'], e); continue
        open(os.path.join(pasta, nome), 'wb').write(dados)
        time.sleep(1)
        cred[nome] = a
        print(f'{nome}  {a["largura"]}x{a["altura"]}  {a["licenca"]}  {a["titulo"]}')
    json.dump(cred, open(cred_f, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main()
