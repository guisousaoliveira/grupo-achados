# A Ilha dos Mortos — roteiro v1 (YouTube, ~10 min)

> Narração em 6 blocos. Gere um áudio por bloco no ElevenLabs (bloco1.mp3 ... bloco6.mp3), texto corrido, sem marcações. Eu estico as pausas depois.
> Título sugerido: "O quadro que obcecou Hitler, Freud e Lênin" · alternativa: "Ninguém sabe o que este quadro mostra"
> Miniatura: o barco com a figura branca, bem fechado, com a água escura. Teste A sem texto; teste B com "NINGUÉM SABE" em vermelho.

## Bloco 1 — Gancho

Em 1933, dois acontecimentos sem nenhuma ligação aparente aconteceram no mesmo ano. Em Hollywood, os cenógrafos de King Kong desenharam a Ilha da Caveira, o lugar mais sombrio que o cinema já tinha mostrado. E na Alemanha, um homem que tinha acabado de chegar ao poder pagou uma fortuna por uma pintura. O nome dele era Adolf Hitler. As duas coisas nasceram da mesma imagem. Essa mesma imagem estava pendurada acima da cama de Lênin. Estava no consultório de Sigmund Freud. Fez Rachmaninoff compor uma de suas peças mais sombrias. Inspirou Salvador Dalí, e anos depois inspirou o artista que criou o monstro de Alien. O escritor Vladimir Nabokov dizia que ela estava em todas as casas de Berlim. Mesmo assim, o homem que a pintou nunca explicou o que ela mostra. Nunca escreveu uma linha sobre o significado. E nem o nome pelo qual o mundo inteiro a conhece foi ele quem escolheu. Esta é a história da Ilha dos Mortos.

