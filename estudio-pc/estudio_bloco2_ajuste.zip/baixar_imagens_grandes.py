# Baixa as imagens do Bloco 2 em 3840 px (Wikimedia Commons) e troca as pequenas em projetos/ilha-b2/media/img.
# Uso: python baixar_imagens_grandes.py
import os, time, urllib.parse, urllib.request
PASTA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'projetos', 'ilha-b2', 'media', 'img')
ARQS = {
    'autorretrato_morte.jpg': 'Arnold_Böcklin_-_Selbstbildnis_mit_fiedelndem_Tod_-_Google_Art_Project.jpg',
    'tritao_nereida.jpg': 'Arnold_Böcklin_-_Triton_and_Nereid.jpg',
    'campos_elisios.jpg': 'Arnold_Böcklin_-_Die_Gefilde_der_Seligen.jpg',
    'bosque_sagrado.jpg': 'Arnold_Böcklin_-_Heiliger_Hain.jpg',
    'a_peste.jpg': 'Arnold_Böcklin_-_Die_Pest.jpg',
    'cemiterio_ingles.jpg': 'English_Cemetery,_Florence.jpg',
}
for local, nome in ARQS.items():
    url = 'https://commons.wikimedia.org/wiki/Special:Redirect/file/' + urllib.parse.quote(nome) + '?width=3840'
    for tentativa in range(4):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'AsterStudio/1.0 (estudio pessoal)'})
            dados = urllib.request.urlopen(req, timeout=120).read()
            if dados[:3] != b'\xff\xd8\xff':
                raise ValueError('não veio um JPEG')
            open(os.path.join(PASTA, local), 'wb').write(dados)
            print('ok', local, len(dados) // 1024, 'KB')
            break
        except Exception as e:
            print('tentando de novo', local, e)
            time.sleep(10 * (tentativa + 1))
    else:
        print('FALHOU', local, '(fica a versão menor)')
    time.sleep(2)
