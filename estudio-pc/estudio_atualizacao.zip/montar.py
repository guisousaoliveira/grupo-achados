# Monta o vídeo a partir do plano de cenas.
# Uso: python montar.py PROJETO [--amostra SEGUNDOS] [--vertical] [--planos 3,4,5 [--juntar]]
# Lê   PROJETO/planos.json, PROJETO/tl_voz.json, PROJETO/voz.wav, PROJETO/media/...
# Gera PROJETO/saida/<nome>.mp4, PROJETO/saida/davinci_<formato>/ (pacote do DaVinci) e PROJETO/saida/conferencia.jpg/.txt
#
# planos.json:
# { "nome": "ilha_dos_mortos",
#   "trilha":  [{"arquivo": "musica/x.mp3", "inicio": 0, "volume_db": 0}],
#   "efeitos": [{"arquivo": "sfx/impacto.mp3", "frase": 12, "volume_db": -6}],
#   "cliques": true, "cliques_db": -9,   (clique de projetor quando troca de imagem; "sem_clique": true num plano desliga)
#   "abertura": 8,   (opcional: segundos só com imagem e trilha antes da narração começar)
#   "planos":  [{"frase": 0, "mode": "full", "img": "x.jpg", "de": [0.5, 0.5, 1], "ate": [0.4, 0.45, 0.6], "etiqueta": ["Título", "Autor (ano)"]},
#               {"frase": 0, "depois": 3.5, "mode": "framed", "img": "y.jpg", "nome": "Pessoa"}, ...] }
# Cada plano começa no início da frase indicada (+ "depois" segundos) ou em "t" segundos.
import json, math, os, shutil, subprocess, sys
from multiprocessing import Pool
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, AQUI)
import motor
from motor import FPS

SR = 48000
PASTA_PC = 'F:/projects/dinheiro-online/web-documentario/{nome}/davinci_{fmt}/'
MUSICA_ABAIXO_DB = 19      # trilha fica ~19 dB abaixo da voz (medido no Velum)


def args():
    a = sys.argv[1:]; proj = a[0]
    amostra = float(a[a.index('--amostra') + 1]) if '--amostra' in a else None
    so = set(int(x) - 1 for x in a[a.index('--planos') + 1].split(',')) if '--planos' in a else None
    return proj, amostra, '--vertical' in a, so


def decodificar(path, canais=1):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-ac', str(canais), '-ar', str(SR), '-f', 'f32le', '-'],
                         capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).reshape(-1, canais).copy()


def media_movel(x, n):
    # igual a np.convolve(x, np.ones(n) / n, 'same'), mas por soma acumulada (milhares de vezes mais rápido)
    c = np.concatenate([[0.0], np.cumsum(x, dtype=np.float64)])
    i = np.arange(len(x)) + (n - 1) // 2
    b = np.clip(i + 1, 0, len(x)); a = np.clip(i - n + 1, 0, len(x))
    return ((c[b] - c[a]) / n).astype(np.float32)


def rms_janela(x, seg):
    n = max(1, int(seg * SR))
    return np.sqrt(np.maximum(media_movel(x ** 2, n), 0) + 1e-12)


def tempos(P, tl):
    fr = tl['frases']
    for s in P:
        if 't' not in s:
            s['t'] = fr[s['frase']]['start'] + s.get('depois', 0)
    P.sort(key=lambda s: s['t'])
    return P


def som_clique(seed):
    # clique de projetor de slides antigo: estalo seco + baque do carrossel ~70 ms depois
    rng = np.random.default_rng(seed)
    n = int(0.45 * SR); t = np.arange(n) / SR; x = np.zeros(n, np.float32)
    def ruido(ini, dur, decai):
        k = np.zeros(n); i0 = int(ini * SR); m = int(dur * SR)
        k[i0:i0 + m] = rng.standard_normal(m) * np.exp(-np.arange(m) / SR * decai)
        return k
    estalo = ruido(0, 0.012, 380)
    estalo = estalo - np.convolve(estalo, np.ones(6) / 6, 'same')        # tira o grave: estalo fino
    baque = ruido(0.07, 0.09, 55)
    baque = np.convolve(baque, np.ones(24) / 24, 'same') * 3             # abafa: baque de madeira/metal
    corpo = np.sin(2 * np.pi * 140 * t) * np.exp(-np.clip(t - 0.07, 0, None) * 40) * (t >= 0.07) * 0.35
    x = (estalo * 0.9 + baque + corpo).astype(np.float32)
    x *= 1 + 0.15 * rng.standard_normal()
    return x / (np.abs(x).max() + 1e-9)


def mesmo_quadro(a, b):
    # vistas diferentes do mesmo quadro não levam clique (toteninsel_basel e toteninsel_met contam como o mesmo)
    ia, ib = a.get('img'), b.get('img')
    return bool(ia and ib and ia.split('_')[0] == ib.split('_')[0] and a['mode'] in ('full', 'framed', 'quote') and b['mode'] in ('full', 'framed', 'quote'))


def mixar(proj, cfg, tl, total, P=None):
    voz = decodificar(os.path.join(proj, 'voz.wav'))[:, 0]
    voz = np.concatenate([np.zeros(int(cfg.get('abertura', 0) * SR), np.float32), voz])  # abertura sem fala
    N = int(total * SR); voz = np.pad(voz, (0, max(0, N - len(voz))))[:N]
    fala = rms_janela(voz, 0.4)
    nivel_voz = np.percentile(fala[fala > 0.01], 60) if (fala > 0.01).any() else 0.1
    mus = np.zeros((N, 2), np.float32)
    for tr in cfg.get('trilha', []):
        m = decodificar(os.path.join(proj, tr['arquivo']), 2)
        i0 = int(tr.get('inicio', 0) * SR)
        if 'corte' in tr:
            m = m[int(tr['corte'] * SR):]
        m = m[:N - i0]
        # fade de 2 s nas pontas de cada faixa
        f = np.ones(len(m)); nf = min(len(m) // 2, 2 * SR)
        f[:nf] = np.linspace(0, 1, nf); f[len(m) - nf:] = np.linspace(1, 0, nf)
        nivel = np.sqrt((m ** 2).mean() + 1e-12)
        g = nivel_voz / nivel * 10 ** (-MUSICA_ABAIXO_DB / 20) * 10 ** (tr.get('volume_db', 0) / 20)
        mus[i0:i0 + len(m)] += m * (f * g)[:, None]
    # nos respiros sem fala a trilha sobe 4 dB, devagar
    ativo = (fala > nivel_voz * 0.25).astype(np.float32)
    duck = 10 ** (4 / 20) - (10 ** (4 / 20) - 1) * media_movel(ativo, SR)
    mus *= duck[:, None]
    fx = np.zeros((N, 2), np.float32)
    for e in cfg.get('efeitos', []):
        x = decodificar(os.path.join(proj, e['arquivo']), 2)
        t = e['t'] if 't' in e else tl['frases'][e['frase']]['start'] + e.get('depois', 0)
        i0 = int(t * SR); x = x[:N - i0] * 10 ** (e.get('volume_db', -6) / 20)
        fx[i0:i0 + len(x)] += x
    if P and cfg.get('cliques', True):
        nivel_clique = nivel_voz * 10 ** (cfg.get('cliques_db', -9) / 20)
        for k in range(1, len(P)):
            if mesmo_quadro(P[k - 1], P[k]) or P[k].get('sem_clique') or P[k - 1].get('fade_out'):
                continue
            c = som_clique(k) * nivel_clique * 4
            i0 = max(0, int((P[k]['t'] - 0.02) * SR)); c = c[:N - i0]
            fx[i0:i0 + len(c)] += np.stack([c * 0.9, c], 1)
    vz = np.stack([voz, voz], 1)
    os.makedirs(os.path.join(proj, 'saida', 'audio'), exist_ok=True)
    for nome, x in [('voz', vz), ('musica', mus), ('efeitos', fx)]:
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', '-',
                        os.path.join(proj, 'saida', 'audio', f'{nome}.wav')], input=x.astype(np.float32).tobytes(), check=True)
    mix = vz + mus + fx
    env = rms_janela(mus.mean(1), 0.2)[::SR // 10]
    env = (env / (env.max() + 1e-9)).round(3).tolist()
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', '-',
                    '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11,alimiter=limit=0.89:level=false', '-ar', str(SR), os.path.join(proj, 'saida', 'audio', 'mix.wav')],
                   input=mix.astype(np.float32).tobytes(), check=True)
    return env


def pacote(proj, nome, fmt, OUT, fb, n, W, H, total):
    from xml.sax.saxutils import escape
    PK = os.path.join(proj, 'saida', f'davinci_{fmt}') + '/'
    for d in ['clipes', 'textos', 'audio']:
        os.makedirs(PK + d, exist_ok=True)
    for i in range(n):
        shutil.copy(f'{OUT}/clipes/plano_{i + 1:03d}.mp4', PK + 'clipes/')
        t = f'{OUT}/textos/texto_{i + 1:03d}.png'
        if os.path.exists(t):
            shutil.copy(t, PK + 'textos/')
    for s in ['voz', 'musica', 'efeitos']:
        shutil.copy(os.path.join(proj, 'saida', 'audio', f'{s}.wav'), PK + f'audio/{s}.wav')
    BASE = 'file:///' + PASTA_PC.format(nome=nome, fmt=fmt)
    T = lambda f: f'{f}/{FPS}s'
    res = [f'<format id="r0" name="{W}x{H} {FPS}p" frameDuration="1/{FPS}s" width="{W}" height="{H}"/>']; k = [1]

    def asset(nm, path, dur, video=True, audio=False, still=False):
        i = f'r{k[0]}'; k[0] += 1
        a = f'id="{i}" name="{escape(nm)}" start="0s" duration="{"0s" if still else T(dur)}"'
        if video:
            a += ' hasVideo="1" format="r0"'
        if audio:
            a += ' hasAudio="1" audioSources="1" audioChannels="2" audioRate="48000"'
        res.append(f'<asset {a}><media-rep kind="original-media" src="{BASE}{path}"/></asset>'); return i
    tot = fb[-1]; spine = []
    for i in range(n):
        d = fb[i + 1] - fb[i]; nm = f'plano_{i + 1:03d}'
        v = asset(nm, f'clipes/{nm}.mp4', d); inner = ''
        if i == 0:
            for s, lane in [('voz', -1), ('musica', -2), ('efeitos', -3)]:
                a = asset(s, f'audio/{s}.wav', tot, video=False, audio=True)
                inner += f'\n  <asset-clip ref="{a}" lane="{lane}" offset="0s" start="0s" duration="{T(tot)}" name="{s}"/>'
        if os.path.exists(PK + f'textos/texto_{i + 1:03d}.png'):
            p = asset(f'texto_{i + 1:03d}', f'textos/texto_{i + 1:03d}.png', d, still=True)
            inner += f'\n  <video ref="{p}" lane="1" offset="0s" start="0s" duration="{T(d)}" name="texto_{i + 1:03d}"/>'
        spine.append(f'<asset-clip ref="{v}" offset="{T(fb[i])}" start="0s" duration="{T(d)}" name="{nm}">{inner}\n</asset-clip>')
    X = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fcpxml>
<fcpxml version="1.9">
<resources>
{chr(10).join(res)}
</resources>
<library><event name="Aster"><project name="{escape(nome)} {fmt}">
<sequence format="r0" duration="{T(tot)}" tcStart="0s" tcFormat="NDF" audioLayout="stereo" audioRate="48k">
<spine>
{chr(10).join(spine)}
</spine>
</sequence></project></event></library>
</fcpxml>'''
    open(PK + 'timeline_davinci.fcpxml', 'w', encoding='utf-8').write(X)


def conferir(proj, P, fb, OUT, W, H, total, n, amostra=False):
    # checagem automática: o que um editor olharia antes de entregar
    from PIL import Image, ImageDraw
    avisos = []
    for i in range(n):
        s = P[i]; d = (fb[i + 1] - fb[i]) / FPS; nome = f'plano {i + 1} ({s["mode"]}, {fb[i] / FPS:.1f}s)'
        if d < 1.0 and s['mode'] != 'black':
            avisos.append(f'{nome}: muito curto ({d:.1f}s), não dá tempo de ver')
        if d > 30:
            avisos.append(f'{nome}: muito longo ({d:.1f}s)')
        if s.get('etiqueta') and d < 2.5:
            avisos.append(f'{nome}: etiqueta aparece por só {d:.1f}s, difícil de ler')
        if s['mode'] == 'full':
            im = motor.carregar(s['img']); w = min(s['de'][2], s.get('ate', s['de'])[2]) * im.width
            if w < W * 0.7:
                avisos.append(f'{nome}: zoom além da resolução da imagem ({int(w)}px pra {W}px de tela), vai ficar borrado')
    voz_fim = json.load(open(os.path.join(proj, 'tl_voz.json'), encoding='utf-8'))['frases'][-1]['end'] + json.load(open(os.path.join(proj, 'planos.json'), encoding='utf-8')).get('abertura', 0)
    if total < voz_fim and not amostra:
        avisos.append('o vídeo termina antes da última frase')
    pico = float(np.abs(decodificar(os.path.join(proj, 'saida', 'audio', 'mix.wav'), 2)).max())
    if pico > 0.99:
        avisos.append(f'áudio estourando (pico {pico:.2f})')
    # folha de contato: um quadro do meio de cada plano
    cols, tw = 6, 320; th = round(tw * H / W); linhas = math.ceil(n / cols)
    folha = Image.new('RGB', (cols * tw, linhas * (th + 18)), (20, 20, 20)); dd = ImageDraw.Draw(folha)
    for i in range(n):
        meio = (fb[i] + fb[i + 1]) / 2 / FPS - fb[i] / FPS
        png = f'{OUT}/_q.png'
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{meio:.2f}', '-i', f'{OUT}/_final/plano_{i + 1:03d}.mp4',
                        '-frames:v', '1', '-vf', f'scale={tw}:{th}', png], check=True)
        x, y = (i % cols) * tw, (i // cols) * (th + 18)
        folha.paste(Image.open(png), (x, y + 18)); dd.text((x + 4, y + 3), f'{i + 1}  {fb[i] / FPS:.1f}s', fill=(230, 200, 120))
    folha.save(os.path.join(proj, 'saida', 'conferencia.jpg'), quality=82)
    open(os.path.join(proj, 'saida', 'conferencia.txt'), 'w', encoding='utf-8').write('\n'.join(avisos) or 'nenhum problema encontrado')
    return avisos


def main():
    proj, amostra, vertical, so = args()
    cfg = json.load(open(os.path.join(proj, 'planos.json'), encoding='utf-8'))
    tl = json.load(open(os.path.join(proj, 'tl_voz.json'), encoding='utf-8'))
    A = cfg.get('abertura', 0)  # segundos de abertura (só imagem e trilha) antes da narração
    if A:
        for f in tl['frases']:
            f['start'] += A; f['end'] += A
        tl['total'] += A
    W, H = (1080, 1920) if vertical else (1920, 1080); fmt = 'vertical' if vertical else 'horizontal'
    total = amostra or cfg.get('total') or tl['total'] + 6
    P = [s for s in tempos(cfg['planos'], tl) if s['t'] < total]
    OUT = os.path.join(proj, 'saida', '_render_' + fmt)
    for d in ['clipes', 'textos', '_final']:
        os.makedirs(f'{OUT}/{d}', exist_ok=True)
    env = mixar(proj, cfg, tl, total, P)
    fb = [round(s['t'] * FPS) for s in P] + [round(total * FPS)]
    jobs = []
    for i, s in enumerate(P):
        s = dict(s, **s.get(fmt, {}))
        if s.get('img'):
            s['img'] = os.path.join(proj, 'media', 'img', s['img'])
        if s['mode'] == 'music':
            s['_env'] = env
        if so is None or i in so:
            jobs.append((i, s, W, H, OUT, fb[i + 1] - fb[i], fb[i] / FPS))
    with Pool(os.cpu_count()) as p:
        for i in p.imap_unordered(motor.render_plano, jobs):
            print(f'plano {i + 1}/{len(P)}', flush=True)
    if so is not None and '--juntar' not in sys.argv:
        return  # só refez os planos; rode de novo com --juntar pra montar o vídeo
    with open(f'{OUT}/_lista.txt', 'w') as f:
        for i in range(len(P)):
            f.write(f"file '_final/plano_{i + 1:03d}.mp4'\n")
    nome = cfg.get('nome', os.path.basename(os.path.abspath(proj)))
    saida = os.path.join(proj, 'saida', f'{nome}_{fmt}{"_amostra" if amostra else ""}.mp4')
    vf = ['-vf', f'fade=t=out:st={total - 0.8}:d=0.8,format=yuv420p'] if amostra else ['-vf', 'format=yuv420p']
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-f', 'concat', '-safe', '0', '-i', f'{OUT}/_lista.txt',
                    '-i', os.path.join(proj, 'saida', 'audio', 'mix.wav'), '-t', str(total)] + vf +
                   ['-c:v', 'libx264', '-preset', 'slow', '-crf', '20', '-c:a', 'aac', '-b:a', '192k',
                    '-movflags', '+faststart', saida], check=True)
    P2 = [dict(s, img=os.path.join(proj, 'media', 'img', s['img'])) if s.get('img') else s for s in P]
    avisos = conferir(proj, P2, fb, OUT, W, H, total, len(P), bool(amostra))
    if not amostra:
        pacote(proj, nome, fmt, OUT, fb, len(P), W, H, total)
    print(f'ok: {saida} ({os.path.getsize(saida) / 1e6:.0f} MB, {len(P)} planos)')
    print('conferência:', '; '.join(avisos) or 'nenhum problema')


if __name__ == '__main__':
    main()
