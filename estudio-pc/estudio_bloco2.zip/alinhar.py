# Alinha a narração do ElevenLabs (um mp3 por bloco) com o roteiro, frase por frase.
# Uso: python alinhar.py PROJETO
# Lê   PROJETO/roteiro.md   (blocos começando com "## ", frases terminadas em . ? ! ou …)
#      PROJETO/voz/bloco1.mp3, bloco2.mp3 ... (mesma ordem dos blocos)
# Gera PROJETO/voz.wav      (blocos colados, com respiro mínimo entre frases e entre blocos)
#      PROJETO/tl_voz.json  (início e fim de cada frase, em segundos, no voz.wav)
#
# Se o tl_voz.json já tiver "cortes" (feito em outra máquina), eles são reaproveitados: o voz.wav sai idêntico sem precisar do whisper.
#
# O ElevenLabs lê o texto exatamente como está, então não precisa de reconhecimento de fala:
# a posição de cada frase é estimada pela quantidade de letras e encaixada no silêncio mais próximo.
import glob, json, os, re, subprocess, sys
import numpy as np

SR = 48000
PAUSA_FRASE = 0.45   # respiro mínimo entre frases (o Velum fica entre 0,4 e 0,7 s)
PAUSA_BLOCO = 1.1    # respiro entre blocos
JANELA = 1.6         # até quantos segundos o corte pode andar pra achar um silêncio


def ler_roteiro(path):
    blocos = []
    for parte in re.split(r'^## ', open(path, encoding='utf-8').read(), flags=re.M)[1:]:
        titulo, _, corpo = parte.partition('\n')
        corpo = re.sub(r'\[[^\]]*\]', ' ', corpo)          # tags de áudio do ElevenLabs não contam
        corpo = re.sub(r'^>.*$|^\s*[-*].*$', ' ', corpo, flags=re.M)  # notas e listas ficam de fora
        corpo = ' '.join(corpo.split())
        frases = [f.strip() for f in re.split(r'(?<=[.?!…])\s+', corpo) if f.strip()]
        blocos.append(dict(titulo=titulo.strip(), frases=frases))
    return blocos


def carregar(path):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'],
                         capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).copy()


def silencios(a, limiar_db=-38, minimo=0.18):
    # janelas de 10 ms abaixo do limiar, agrupadas
    win = SR // 100
    n = len(a) // win
    rms = np.sqrt((a[:n * win].reshape(n, win) ** 2).mean(1) + 1e-12)
    baixo = 20 * np.log10(rms) < limiar_db
    out, ini = [], None
    for i, b in enumerate(np.append(baixo, False)):
        if b and ini is None:
            ini = i
        elif not b and ini is not None:
            if (i - ini) / 100 >= minimo:
                out.append((ini / 100, i / 100))
            ini = None
    return out


def alinhar_bloco(a, frases):
    dur = len(a) / SR
    sil = silencios(a)
    # fala útil = do fim do silêncio inicial ao começo do silêncio final
    t_ini = sil[0][1] if sil and sil[0][0] <= 0.05 else 0.0
    t_fim = sil[-1][0] if sil and sil[-1][1] >= dur - 0.05 else dur
    internos = [s for s in sil if s[0] > t_ini and s[1] < t_fim]
    letras = np.array([len(f) for f in frases], float)
    alvo = t_ini + (t_fim - t_ini) * np.cumsum(letras)[:-1] / letras.sum()
    cortes, usados = [], set()
    for t in alvo:
        cand = [(abs((s[0] + s[1]) / 2 - t) - (s[1] - s[0]), k) for k, s in enumerate(internos)
                if k not in usados and abs((s[0] + s[1]) / 2 - t) <= JANELA]
        if cand:
            k = min(cand)[1]; usados.add(k); cortes.append(internos[k])
        else:
            cortes.append((t, t))  # sem silêncio perto: corta na estimativa
    cortes.sort()
    ini = [t_ini] + [c[1] for c in cortes]
    fim = [c[0] for c in cortes] + [t_fim]
    return list(zip(ini, fim)), (t_ini, t_fim)


def modelo_whisper():
    # transcrição local (sherpa-onnx whisper small) pra achar onde cada frase realmente começa
    try:
        import sherpa_onnx
    except ImportError:
        return None
    m = sorted(glob.glob(os.environ.get('WHISPER_DIR', '/tmp/velum/model/*/')))
    if not m:
        return None
    m = m[0]
    return sherpa_onnx.OfflineRecognizer.from_whisper(
        encoder=m + 'small-encoder.int8.onnx', decoder=m + 'small-decoder.int8.onnx',
        tokens=m + 'small-tokens.txt', language='pt', task='transcribe', num_threads=4)


def alinhar_por_transcricao(a, frases, rec):
    # corta o áudio nos silêncios, transcreve cada pedaço e encaixa o fim de cada frase
    # no corte cuja quantidade de letras transcritas até ali mais se aproxima da do roteiro
    dur = len(a) / SR
    sil = silencios(a, minimo=0.12)
    t_ini = sil[0][1] if sil and sil[0][0] <= 0.05 else 0.0
    t_fim = sil[-1][0] if sil and sil[-1][1] >= dur - 0.05 else dur
    internos = [s for s in sil if s[0] > t_ini and s[1] < t_fim]
    bordas = [t_ini] + [(s[0] + s[1]) / 2 for s in internos] + [t_fim]
    letras_tr = []
    for k in range(len(bordas) - 1):
        st = rec.create_stream()
        st.accept_waveform(SR, a[int(bordas[k] * SR):int(bordas[k + 1] * SR)])
        rec.decode_stream(st)
        letras_tr.append(len(re.sub(r'\W', '', st.result.text)))
    ct = np.cumsum(letras_tr) / max(1, sum(letras_tr))
    letras = np.array([len(re.sub(r'\W', '', f)) for f in frases], float)
    cs = np.cumsum(letras)[:-1] / letras.sum()
    escolhidos, ultimo = [], -1
    for j, alvo in enumerate(cs):
        resta = len(cs) - j - 1  # deixa cortes suficientes pras frases seguintes
        cand = range(ultimo + 1, len(internos) - resta)
        k = min(cand, key=lambda k: abs(ct[k] - alvo)) if len(cand) else ultimo + 1
        escolhidos.append(internos[min(k, len(internos) - 1)]); ultimo = k
    ini = [t_ini] + [c[1] for c in escolhidos]
    fim = [c[0] for c in escolhidos] + [t_fim]
    return list(zip(ini, fim)), (t_ini, t_fim)


def main():
    proj = sys.argv[1]
    blocos = ler_roteiro(os.path.join(proj, 'roteiro.md'))
    audios = sorted(glob.glob(os.path.join(proj, 'voz', 'bloco*.*')), key=lambda p: int(re.findall(r'\d+', os.path.basename(p))[0]))
    if len(audios) != len(blocos):
        sys.exit(f'O roteiro tem {len(blocos)} blocos, mas achei {len(audios)} áudios em voz/. Nomeie bloco1.mp3, bloco2.mp3...')
    rec = modelo_whisper()
    # cortes já calculados em outra máquina (tl_voz.json com "cortes"): refaz o voz.wav idêntico sem whisper
    tl_path = os.path.join(proj, 'tl_voz.json')
    prontos = json.load(open(tl_path, encoding='utf-8')).get('cortes') if os.path.exists(tl_path) else None
    if prontos and len(prontos) != len(blocos):
        prontos = None
    print('alinhamento:', 'cortes prontos do tl_voz.json' if prontos else 'transcrição (whisper)' if rec else 'proporção de letras')
    saida, frases_tl, t, cortes = [], [], 0.0, []
    for b, (bloco, path) in enumerate(zip(blocos, audios), 1):
        a = carregar(path)
        if prontos and abs(prontos[b - 1].get('dur', 0) - len(a) / SR) > 0.01:
            sys.exit(f'O áudio do bloco {b} não é o mesmo dos cortes do tl_voz.json. Apague o tl_voz.json para alinhar de novo.')
        if prontos:
            tempos, (t_ini, t_fim) = [tuple(x) for x in prontos[b - 1]['tempos']], tuple(prontos[b - 1]['limites'])
        elif rec:
            tempos, (t_ini, t_fim) = alinhar_por_transcricao(a, bloco['frases'], rec)
        else:
            tempos, (t_ini, t_fim) = alinhar_bloco(a, bloco['frases'])
        cortes.append(dict(tempos=[[round(float(x), 5) for x in p] for p in tempos], limites=[round(float(t_ini), 5), round(float(t_fim), 5)], dur=round(len(a) / SR, 4)))
        if b > 1:
            saida.append(np.zeros(int(PAUSA_BLOCO * SR), np.float32)); t += PAUSA_BLOCO
        for k, ((i0, i1), texto) in enumerate(zip(tempos, bloco['frases'])):
            # cada frase vai do fim da pausa anterior ao começo da próxima; pausas curtas são esticadas
            prox = tempos[k + 1][0] if k + 1 < len(tempos) else t_fim
            pausa_orig = prox - i1
            trecho = a[int(i0 * SR):int(i1 * SR)]
            frases_tl.append(dict(i=len(frases_tl), bloco=b, texto=texto, start=round(t, 3), end=round(t + len(trecho) / SR, 3)))
            saida.append(trecho); t += len(trecho) / SR
            if k + 1 < len(tempos):
                p = max(pausa_orig, PAUSA_FRASE)
                meio = a[int(i1 * SR):int(prox * SR)]          # mantém o respiro original
                extra = int(max(0, p - pausa_orig) * SR)
                saida.append(np.concatenate([meio, np.zeros(extra, np.float32)])); t += p
        print(f'bloco {b}: {len(bloco["frases"])} frases, {t_fim - t_ini:.1f}s de fala')
    voz = np.concatenate(saida)
    voz = np.concatenate([np.zeros(int(0.4 * SR), np.float32), voz, np.zeros(int(1.0 * SR), np.float32)])
    for f in frases_tl:
        f['start'] = round(f['start'] + 0.4, 3); f['end'] = round(f['end'] + 0.4, 3)
    total = len(voz) / SR
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '1', '-i', '-',
                    os.path.join(proj, 'voz.wav')], input=voz.tobytes(), check=True)
    json.dump(dict(total=round(total, 3), frases=frases_tl, blocos=[b['titulo'] for b in blocos], cortes=cortes),
              open(os.path.join(proj, 'tl_voz.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'ok: {len(frases_tl)} frases, {total / 60:.1f} min ({sum(len(f["texto"].split()) for f in frases_tl) / (total / 60):.0f} palavras/min)')


if __name__ == '__main__':
    main()
