# A Ilha dos Mortos

## Bloco 2 — O pintor


Arnold Böcklin nasceu em Basileia, na Suíça, em 1827. Enquanto os pintores da época retratavam a burguesia e paisagens tranquilas, ele pintava outra coisa. Tritões saindo do mar. Ninfas em ruínas. Deuses antigos que ninguém mais adorava. Böcklin passou boa parte da vida na Itália, cercado de templos caídos e cemitérios antigos, e isso aparece em quase tudo o que ele fez. Mas existe um motivo mais pessoal para a morte estar tão presente nos quadros dele. Böcklin teve catorze filhos. Oito morreram. Em 1872, ele pintou um autorretrato que diz muito sobre isso. Ele aparece com o pincel na mão, olhando para frente, e logo atrás dele, quase encostado no ouvido, um esqueleto toca violino. Böcklin não pinta a morte como um susto. Ela está ali do lado, tocando, como uma companhia de trabalho. Em Florença, o ateliê dele ficava a poucos passos de um pequeno cemitério protestante, cheio de ciprestes, cercado de muros. Era o Cemitério Inglês. E foi ali que ele enterrou uma de suas filhas, Maria, ainda bebê.

